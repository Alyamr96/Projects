# Generated from milestone_1.g4 by ANTLR 4.7.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
from typing.io import TextIO
import sys

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3}")
        buf.write("\7\4\2\t\2\3\2\3\2\3\2\2\2\3\2\2\3\3\2\3}\2\5\2\4\3\2")
        buf.write("\2\2\4\5\t\2\2\2\5\3\3\2\2\2\2")
        return buf.getvalue()


class milestone_1Parser ( Parser ):

    grammarFileName = "milestone_1.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "'var'", "'and'", 
                     "'addr'", "'as'", "'asm'", "'bind'", "'block'", "'break'", 
                     "'case'", "'cast'", "'concept'", "'const'", "'continue'", 
                     "'converter'", "'defer'", "'discard'", "'distinct'", 
                     "'div'", "'do'", "'elif'", "'else'", "'end'", "'enum'", 
                     "'except'", "'export'", "'finally'", "'for'", "'from'", 
                     "'func'", "'if'", "'import'", "'in'", "'include'", 
                     "'interface'", "'is'", "'isnot'", "'iterator'", "'let'", 
                     "'macro'", "'method'", "'mixin'", "'mod'", "'nil'", 
                     "'not'", "'notin'", "'object'", "'of'", "'or'", "'out'", 
                     "'proc'", "'ptr'", "'raise'", "'ref'", "'return'", 
                     "'shl'", "'shr'", "'static'", "'template'", "'try'", 
                     "'tuple'", "'type'", "'using'", "'when'", "'while'", 
                     "'xor'", "'yield'", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "'=='", "'+'", 
                     "'*'", "'-'", "'/'", "'~'", "'&'", "'|'", "'<'", "'>'", 
                     "'at'", "'%'", "'!'", "'^'", "'.'", "':'", "'('", "')'", 
                     "'{'", "'}'", "'['", "']'", "','", "';'" ]

    symbolicNames = [ "<INVALID>", "NEWLINE", "WHITESPACE", "VARIABLE", 
                      "AND", "ADDR", "AS", "ASM", "BIND", "BLOCK", "BREAK", 
                      "CASE", "CAST", "CONCEPT", "CONST", "CONTINUE", "CONVERTER", 
                      "DEFER", "DISCARD", "DISTINCT", "DIV", "DO", "ELIF", 
                      "ELSE", "END", "ENUM", "EXCEPT", "EXPORT", "FINALLY", 
                      "FOR", "FROM", "FUNC", "IF", "IMPORT", "IN", "INCLUDE", 
                      "INTERFACE", "IS", "ISNOT", "ITERATOR", "LET", "MACRO", 
                      "METHOD", "MIXIN", "MOD", "NIL", "NOT", "NOTIN", "OBJECT", 
                      "OF", "OR", "OUT", "PROC", "PTR", "RAISE", "REF", 
                      "RETURN", "SHL", "SHR", "STATIC", "TEMPLATE", "TRY", 
                      "TUPLE", "TYPE", "USING", "WHEN", "WHILE", "XOR", 
                      "YIELD", "LETTER", "DIGIT", "IDENTIFIER", "HEXDIGIT", 
                      "OCTDIGIT", "BINDIGIT", "HEX_LIT", "DEC_LIT", "OCT_LIT", 
                      "BIN_LIT", "INT_LIT", "INT8_LIT", "INT16_LIT", "INT32_LIT", 
                      "INT64_LIT", "UINT_LIT", "UINT8_LIT", "UINT16_LIT", 
                      "UINT32_LIT", "UINT64_LIT", "EXP", "FLOAT_LIT", "FLOAT32_SUFFIX", 
                      "FLOAT32_LIT", "FLOAT64_SUFFIX", "FLOAT64_LIT", "EQUALS_OPERATOR", 
                      "ADD_OPERATOR", "MUL_OPERATOR", "MINUS_OPERATOR", 
                      "DIV_OPERATOR", "BITWISE_NOT_OPERATOR", "AND_OPERATOR", 
                      "OR_OPERATOR", "LESS_THAN", "GREATER_THAN", "AT", 
                      "MODULUS", "NOT_OPERATOR", "XOR_OPERATOR", "DOT", 
                      "COLON", "OPEN_PAREN", "CLOSE_PAREN", "OPEN_BRACE", 
                      "CLOSE_BRACE", "OPEN_BRACK", "CLOSE_BRACK", "COMMA", 
                      "SEMI_COLON", "STR_LIT", "TRIPLESTR_LIT", "RSTR_LIT", 
                      "COMMENT", "MULTILINE_COMMENTS" ]

    RULE_expr = 0

    ruleNames =  [ "expr" ]

    EOF = Token.EOF
    NEWLINE=1
    WHITESPACE=2
    VARIABLE=3
    AND=4
    ADDR=5
    AS=6
    ASM=7
    BIND=8
    BLOCK=9
    BREAK=10
    CASE=11
    CAST=12
    CONCEPT=13
    CONST=14
    CONTINUE=15
    CONVERTER=16
    DEFER=17
    DISCARD=18
    DISTINCT=19
    DIV=20
    DO=21
    ELIF=22
    ELSE=23
    END=24
    ENUM=25
    EXCEPT=26
    EXPORT=27
    FINALLY=28
    FOR=29
    FROM=30
    FUNC=31
    IF=32
    IMPORT=33
    IN=34
    INCLUDE=35
    INTERFACE=36
    IS=37
    ISNOT=38
    ITERATOR=39
    LET=40
    MACRO=41
    METHOD=42
    MIXIN=43
    MOD=44
    NIL=45
    NOT=46
    NOTIN=47
    OBJECT=48
    OF=49
    OR=50
    OUT=51
    PROC=52
    PTR=53
    RAISE=54
    REF=55
    RETURN=56
    SHL=57
    SHR=58
    STATIC=59
    TEMPLATE=60
    TRY=61
    TUPLE=62
    TYPE=63
    USING=64
    WHEN=65
    WHILE=66
    XOR=67
    YIELD=68
    LETTER=69
    DIGIT=70
    IDENTIFIER=71
    HEXDIGIT=72
    OCTDIGIT=73
    BINDIGIT=74
    HEX_LIT=75
    DEC_LIT=76
    OCT_LIT=77
    BIN_LIT=78
    INT_LIT=79
    INT8_LIT=80
    INT16_LIT=81
    INT32_LIT=82
    INT64_LIT=83
    UINT_LIT=84
    UINT8_LIT=85
    UINT16_LIT=86
    UINT32_LIT=87
    UINT64_LIT=88
    EXP=89
    FLOAT_LIT=90
    FLOAT32_SUFFIX=91
    FLOAT32_LIT=92
    FLOAT64_SUFFIX=93
    FLOAT64_LIT=94
    EQUALS_OPERATOR=95
    ADD_OPERATOR=96
    MUL_OPERATOR=97
    MINUS_OPERATOR=98
    DIV_OPERATOR=99
    BITWISE_NOT_OPERATOR=100
    AND_OPERATOR=101
    OR_OPERATOR=102
    LESS_THAN=103
    GREATER_THAN=104
    AT=105
    MODULUS=106
    NOT_OPERATOR=107
    XOR_OPERATOR=108
    DOT=109
    COLON=110
    OPEN_PAREN=111
    CLOSE_PAREN=112
    OPEN_BRACE=113
    CLOSE_BRACE=114
    OPEN_BRACK=115
    CLOSE_BRACK=116
    COMMA=117
    SEMI_COLON=118
    STR_LIT=119
    TRIPLESTR_LIT=120
    RSTR_LIT=121
    COMMENT=122
    MULTILINE_COMMENTS=123

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.7.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class ExprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NEWLINE(self):
            return self.getToken(milestone_1Parser.NEWLINE, 0)

        def WHITESPACE(self):
            return self.getToken(milestone_1Parser.WHITESPACE, 0)

        def VARIABLE(self):
            return self.getToken(milestone_1Parser.VARIABLE, 0)

        def AND(self):
            return self.getToken(milestone_1Parser.AND, 0)

        def ADDR(self):
            return self.getToken(milestone_1Parser.ADDR, 0)

        def AS(self):
            return self.getToken(milestone_1Parser.AS, 0)

        def ASM(self):
            return self.getToken(milestone_1Parser.ASM, 0)

        def BIND(self):
            return self.getToken(milestone_1Parser.BIND, 0)

        def BLOCK(self):
            return self.getToken(milestone_1Parser.BLOCK, 0)

        def BREAK(self):
            return self.getToken(milestone_1Parser.BREAK, 0)

        def CASE(self):
            return self.getToken(milestone_1Parser.CASE, 0)

        def CAST(self):
            return self.getToken(milestone_1Parser.CAST, 0)

        def CONCEPT(self):
            return self.getToken(milestone_1Parser.CONCEPT, 0)

        def CONST(self):
            return self.getToken(milestone_1Parser.CONST, 0)

        def CONTINUE(self):
            return self.getToken(milestone_1Parser.CONTINUE, 0)

        def CONVERTER(self):
            return self.getToken(milestone_1Parser.CONVERTER, 0)

        def DEFER(self):
            return self.getToken(milestone_1Parser.DEFER, 0)

        def DISCARD(self):
            return self.getToken(milestone_1Parser.DISCARD, 0)

        def DISTINCT(self):
            return self.getToken(milestone_1Parser.DISTINCT, 0)

        def DIV(self):
            return self.getToken(milestone_1Parser.DIV, 0)

        def DO(self):
            return self.getToken(milestone_1Parser.DO, 0)

        def ELIF(self):
            return self.getToken(milestone_1Parser.ELIF, 0)

        def ELSE(self):
            return self.getToken(milestone_1Parser.ELSE, 0)

        def END(self):
            return self.getToken(milestone_1Parser.END, 0)

        def ENUM(self):
            return self.getToken(milestone_1Parser.ENUM, 0)

        def EXCEPT(self):
            return self.getToken(milestone_1Parser.EXCEPT, 0)

        def EXPORT(self):
            return self.getToken(milestone_1Parser.EXPORT, 0)

        def FINALLY(self):
            return self.getToken(milestone_1Parser.FINALLY, 0)

        def FOR(self):
            return self.getToken(milestone_1Parser.FOR, 0)

        def FROM(self):
            return self.getToken(milestone_1Parser.FROM, 0)

        def FUNC(self):
            return self.getToken(milestone_1Parser.FUNC, 0)

        def IF(self):
            return self.getToken(milestone_1Parser.IF, 0)

        def IMPORT(self):
            return self.getToken(milestone_1Parser.IMPORT, 0)

        def IN(self):
            return self.getToken(milestone_1Parser.IN, 0)

        def INCLUDE(self):
            return self.getToken(milestone_1Parser.INCLUDE, 0)

        def INTERFACE(self):
            return self.getToken(milestone_1Parser.INTERFACE, 0)

        def IS(self):
            return self.getToken(milestone_1Parser.IS, 0)

        def ISNOT(self):
            return self.getToken(milestone_1Parser.ISNOT, 0)

        def ITERATOR(self):
            return self.getToken(milestone_1Parser.ITERATOR, 0)

        def LET(self):
            return self.getToken(milestone_1Parser.LET, 0)

        def MACRO(self):
            return self.getToken(milestone_1Parser.MACRO, 0)

        def METHOD(self):
            return self.getToken(milestone_1Parser.METHOD, 0)

        def MIXIN(self):
            return self.getToken(milestone_1Parser.MIXIN, 0)

        def MOD(self):
            return self.getToken(milestone_1Parser.MOD, 0)

        def NIL(self):
            return self.getToken(milestone_1Parser.NIL, 0)

        def NOT(self):
            return self.getToken(milestone_1Parser.NOT, 0)

        def NOTIN(self):
            return self.getToken(milestone_1Parser.NOTIN, 0)

        def OBJECT(self):
            return self.getToken(milestone_1Parser.OBJECT, 0)

        def OF(self):
            return self.getToken(milestone_1Parser.OF, 0)

        def OR(self):
            return self.getToken(milestone_1Parser.OR, 0)

        def OUT(self):
            return self.getToken(milestone_1Parser.OUT, 0)

        def PROC(self):
            return self.getToken(milestone_1Parser.PROC, 0)

        def PTR(self):
            return self.getToken(milestone_1Parser.PTR, 0)

        def RAISE(self):
            return self.getToken(milestone_1Parser.RAISE, 0)

        def REF(self):
            return self.getToken(milestone_1Parser.REF, 0)

        def RETURN(self):
            return self.getToken(milestone_1Parser.RETURN, 0)

        def SHL(self):
            return self.getToken(milestone_1Parser.SHL, 0)

        def SHR(self):
            return self.getToken(milestone_1Parser.SHR, 0)

        def STATIC(self):
            return self.getToken(milestone_1Parser.STATIC, 0)

        def TEMPLATE(self):
            return self.getToken(milestone_1Parser.TEMPLATE, 0)

        def TRY(self):
            return self.getToken(milestone_1Parser.TRY, 0)

        def TUPLE(self):
            return self.getToken(milestone_1Parser.TUPLE, 0)

        def TYPE(self):
            return self.getToken(milestone_1Parser.TYPE, 0)

        def USING(self):
            return self.getToken(milestone_1Parser.USING, 0)

        def WHEN(self):
            return self.getToken(milestone_1Parser.WHEN, 0)

        def WHILE(self):
            return self.getToken(milestone_1Parser.WHILE, 0)

        def XOR(self):
            return self.getToken(milestone_1Parser.XOR, 0)

        def YIELD(self):
            return self.getToken(milestone_1Parser.YIELD, 0)

        def LETTER(self):
            return self.getToken(milestone_1Parser.LETTER, 0)

        def DIGIT(self):
            return self.getToken(milestone_1Parser.DIGIT, 0)

        def IDENTIFIER(self):
            return self.getToken(milestone_1Parser.IDENTIFIER, 0)

        def HEXDIGIT(self):
            return self.getToken(milestone_1Parser.HEXDIGIT, 0)

        def OCTDIGIT(self):
            return self.getToken(milestone_1Parser.OCTDIGIT, 0)

        def BINDIGIT(self):
            return self.getToken(milestone_1Parser.BINDIGIT, 0)

        def HEX_LIT(self):
            return self.getToken(milestone_1Parser.HEX_LIT, 0)

        def DEC_LIT(self):
            return self.getToken(milestone_1Parser.DEC_LIT, 0)

        def OCT_LIT(self):
            return self.getToken(milestone_1Parser.OCT_LIT, 0)

        def BIN_LIT(self):
            return self.getToken(milestone_1Parser.BIN_LIT, 0)

        def INT_LIT(self):
            return self.getToken(milestone_1Parser.INT_LIT, 0)

        def INT8_LIT(self):
            return self.getToken(milestone_1Parser.INT8_LIT, 0)

        def INT16_LIT(self):
            return self.getToken(milestone_1Parser.INT16_LIT, 0)

        def INT32_LIT(self):
            return self.getToken(milestone_1Parser.INT32_LIT, 0)

        def INT64_LIT(self):
            return self.getToken(milestone_1Parser.INT64_LIT, 0)

        def UINT_LIT(self):
            return self.getToken(milestone_1Parser.UINT_LIT, 0)

        def UINT8_LIT(self):
            return self.getToken(milestone_1Parser.UINT8_LIT, 0)

        def UINT16_LIT(self):
            return self.getToken(milestone_1Parser.UINT16_LIT, 0)

        def UINT32_LIT(self):
            return self.getToken(milestone_1Parser.UINT32_LIT, 0)

        def UINT64_LIT(self):
            return self.getToken(milestone_1Parser.UINT64_LIT, 0)

        def EXP(self):
            return self.getToken(milestone_1Parser.EXP, 0)

        def FLOAT_LIT(self):
            return self.getToken(milestone_1Parser.FLOAT_LIT, 0)

        def FLOAT32_SUFFIX(self):
            return self.getToken(milestone_1Parser.FLOAT32_SUFFIX, 0)

        def FLOAT32_LIT(self):
            return self.getToken(milestone_1Parser.FLOAT32_LIT, 0)

        def FLOAT64_SUFFIX(self):
            return self.getToken(milestone_1Parser.FLOAT64_SUFFIX, 0)

        def FLOAT64_LIT(self):
            return self.getToken(milestone_1Parser.FLOAT64_LIT, 0)

        def EQUALS_OPERATOR(self):
            return self.getToken(milestone_1Parser.EQUALS_OPERATOR, 0)

        def ADD_OPERATOR(self):
            return self.getToken(milestone_1Parser.ADD_OPERATOR, 0)

        def MUL_OPERATOR(self):
            return self.getToken(milestone_1Parser.MUL_OPERATOR, 0)

        def MINUS_OPERATOR(self):
            return self.getToken(milestone_1Parser.MINUS_OPERATOR, 0)

        def DIV_OPERATOR(self):
            return self.getToken(milestone_1Parser.DIV_OPERATOR, 0)

        def BITWISE_NOT_OPERATOR(self):
            return self.getToken(milestone_1Parser.BITWISE_NOT_OPERATOR, 0)

        def AND_OPERATOR(self):
            return self.getToken(milestone_1Parser.AND_OPERATOR, 0)

        def OR_OPERATOR(self):
            return self.getToken(milestone_1Parser.OR_OPERATOR, 0)

        def LESS_THAN(self):
            return self.getToken(milestone_1Parser.LESS_THAN, 0)

        def GREATER_THAN(self):
            return self.getToken(milestone_1Parser.GREATER_THAN, 0)

        def AT(self):
            return self.getToken(milestone_1Parser.AT, 0)

        def MODULUS(self):
            return self.getToken(milestone_1Parser.MODULUS, 0)

        def NOT_OPERATOR(self):
            return self.getToken(milestone_1Parser.NOT_OPERATOR, 0)

        def XOR_OPERATOR(self):
            return self.getToken(milestone_1Parser.XOR_OPERATOR, 0)

        def DOT(self):
            return self.getToken(milestone_1Parser.DOT, 0)

        def COLON(self):
            return self.getToken(milestone_1Parser.COLON, 0)

        def OPEN_PAREN(self):
            return self.getToken(milestone_1Parser.OPEN_PAREN, 0)

        def CLOSE_PAREN(self):
            return self.getToken(milestone_1Parser.CLOSE_PAREN, 0)

        def OPEN_BRACE(self):
            return self.getToken(milestone_1Parser.OPEN_BRACE, 0)

        def CLOSE_BRACE(self):
            return self.getToken(milestone_1Parser.CLOSE_BRACE, 0)

        def OPEN_BRACK(self):
            return self.getToken(milestone_1Parser.OPEN_BRACK, 0)

        def CLOSE_BRACK(self):
            return self.getToken(milestone_1Parser.CLOSE_BRACK, 0)

        def COMMA(self):
            return self.getToken(milestone_1Parser.COMMA, 0)

        def SEMI_COLON(self):
            return self.getToken(milestone_1Parser.SEMI_COLON, 0)

        def STR_LIT(self):
            return self.getToken(milestone_1Parser.STR_LIT, 0)

        def TRIPLESTR_LIT(self):
            return self.getToken(milestone_1Parser.TRIPLESTR_LIT, 0)

        def RSTR_LIT(self):
            return self.getToken(milestone_1Parser.RSTR_LIT, 0)

        def COMMENT(self):
            return self.getToken(milestone_1Parser.COMMENT, 0)

        def MULTILINE_COMMENTS(self):
            return self.getToken(milestone_1Parser.MULTILINE_COMMENTS, 0)

        def getRuleIndex(self):
            return milestone_1Parser.RULE_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr" ):
                listener.enterExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr" ):
                listener.exitExpr(self)




    def expr(self):

        localctx = milestone_1Parser.ExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_expr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 2
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << milestone_1Parser.NEWLINE) | (1 << milestone_1Parser.WHITESPACE) | (1 << milestone_1Parser.VARIABLE) | (1 << milestone_1Parser.AND) | (1 << milestone_1Parser.ADDR) | (1 << milestone_1Parser.AS) | (1 << milestone_1Parser.ASM) | (1 << milestone_1Parser.BIND) | (1 << milestone_1Parser.BLOCK) | (1 << milestone_1Parser.BREAK) | (1 << milestone_1Parser.CASE) | (1 << milestone_1Parser.CAST) | (1 << milestone_1Parser.CONCEPT) | (1 << milestone_1Parser.CONST) | (1 << milestone_1Parser.CONTINUE) | (1 << milestone_1Parser.CONVERTER) | (1 << milestone_1Parser.DEFER) | (1 << milestone_1Parser.DISCARD) | (1 << milestone_1Parser.DISTINCT) | (1 << milestone_1Parser.DIV) | (1 << milestone_1Parser.DO) | (1 << milestone_1Parser.ELIF) | (1 << milestone_1Parser.ELSE) | (1 << milestone_1Parser.END) | (1 << milestone_1Parser.ENUM) | (1 << milestone_1Parser.EXCEPT) | (1 << milestone_1Parser.EXPORT) | (1 << milestone_1Parser.FINALLY) | (1 << milestone_1Parser.FOR) | (1 << milestone_1Parser.FROM) | (1 << milestone_1Parser.FUNC) | (1 << milestone_1Parser.IF) | (1 << milestone_1Parser.IMPORT) | (1 << milestone_1Parser.IN) | (1 << milestone_1Parser.INCLUDE) | (1 << milestone_1Parser.INTERFACE) | (1 << milestone_1Parser.IS) | (1 << milestone_1Parser.ISNOT) | (1 << milestone_1Parser.ITERATOR) | (1 << milestone_1Parser.LET) | (1 << milestone_1Parser.MACRO) | (1 << milestone_1Parser.METHOD) | (1 << milestone_1Parser.MIXIN) | (1 << milestone_1Parser.MOD) | (1 << milestone_1Parser.NIL) | (1 << milestone_1Parser.NOT) | (1 << milestone_1Parser.NOTIN) | (1 << milestone_1Parser.OBJECT) | (1 << milestone_1Parser.OF) | (1 << milestone_1Parser.OR) | (1 << milestone_1Parser.OUT) | (1 << milestone_1Parser.PROC) | (1 << milestone_1Parser.PTR) | (1 << milestone_1Parser.RAISE) | (1 << milestone_1Parser.REF) | (1 << milestone_1Parser.RETURN) | (1 << milestone_1Parser.SHL) | (1 << milestone_1Parser.SHR) | (1 << milestone_1Parser.STATIC) | (1 << milestone_1Parser.TEMPLATE) | (1 << milestone_1Parser.TRY) | (1 << milestone_1Parser.TUPLE) | (1 << milestone_1Parser.TYPE))) != 0) or ((((_la - 64)) & ~0x3f) == 0 and ((1 << (_la - 64)) & ((1 << (milestone_1Parser.USING - 64)) | (1 << (milestone_1Parser.WHEN - 64)) | (1 << (milestone_1Parser.WHILE - 64)) | (1 << (milestone_1Parser.XOR - 64)) | (1 << (milestone_1Parser.YIELD - 64)) | (1 << (milestone_1Parser.LETTER - 64)) | (1 << (milestone_1Parser.DIGIT - 64)) | (1 << (milestone_1Parser.IDENTIFIER - 64)) | (1 << (milestone_1Parser.HEXDIGIT - 64)) | (1 << (milestone_1Parser.OCTDIGIT - 64)) | (1 << (milestone_1Parser.BINDIGIT - 64)) | (1 << (milestone_1Parser.HEX_LIT - 64)) | (1 << (milestone_1Parser.DEC_LIT - 64)) | (1 << (milestone_1Parser.OCT_LIT - 64)) | (1 << (milestone_1Parser.BIN_LIT - 64)) | (1 << (milestone_1Parser.INT_LIT - 64)) | (1 << (milestone_1Parser.INT8_LIT - 64)) | (1 << (milestone_1Parser.INT16_LIT - 64)) | (1 << (milestone_1Parser.INT32_LIT - 64)) | (1 << (milestone_1Parser.INT64_LIT - 64)) | (1 << (milestone_1Parser.UINT_LIT - 64)) | (1 << (milestone_1Parser.UINT8_LIT - 64)) | (1 << (milestone_1Parser.UINT16_LIT - 64)) | (1 << (milestone_1Parser.UINT32_LIT - 64)) | (1 << (milestone_1Parser.UINT64_LIT - 64)) | (1 << (milestone_1Parser.EXP - 64)) | (1 << (milestone_1Parser.FLOAT_LIT - 64)) | (1 << (milestone_1Parser.FLOAT32_SUFFIX - 64)) | (1 << (milestone_1Parser.FLOAT32_LIT - 64)) | (1 << (milestone_1Parser.FLOAT64_SUFFIX - 64)) | (1 << (milestone_1Parser.FLOAT64_LIT - 64)) | (1 << (milestone_1Parser.EQUALS_OPERATOR - 64)) | (1 << (milestone_1Parser.ADD_OPERATOR - 64)) | (1 << (milestone_1Parser.MUL_OPERATOR - 64)) | (1 << (milestone_1Parser.MINUS_OPERATOR - 64)) | (1 << (milestone_1Parser.DIV_OPERATOR - 64)) | (1 << (milestone_1Parser.BITWISE_NOT_OPERATOR - 64)) | (1 << (milestone_1Parser.AND_OPERATOR - 64)) | (1 << (milestone_1Parser.OR_OPERATOR - 64)) | (1 << (milestone_1Parser.LESS_THAN - 64)) | (1 << (milestone_1Parser.GREATER_THAN - 64)) | (1 << (milestone_1Parser.AT - 64)) | (1 << (milestone_1Parser.MODULUS - 64)) | (1 << (milestone_1Parser.NOT_OPERATOR - 64)) | (1 << (milestone_1Parser.XOR_OPERATOR - 64)) | (1 << (milestone_1Parser.DOT - 64)) | (1 << (milestone_1Parser.COLON - 64)) | (1 << (milestone_1Parser.OPEN_PAREN - 64)) | (1 << (milestone_1Parser.CLOSE_PAREN - 64)) | (1 << (milestone_1Parser.OPEN_BRACE - 64)) | (1 << (milestone_1Parser.CLOSE_BRACE - 64)) | (1 << (milestone_1Parser.OPEN_BRACK - 64)) | (1 << (milestone_1Parser.CLOSE_BRACK - 64)) | (1 << (milestone_1Parser.COMMA - 64)) | (1 << (milestone_1Parser.SEMI_COLON - 64)) | (1 << (milestone_1Parser.STR_LIT - 64)) | (1 << (milestone_1Parser.TRIPLESTR_LIT - 64)) | (1 << (milestone_1Parser.RSTR_LIT - 64)) | (1 << (milestone_1Parser.COMMENT - 64)) | (1 << (milestone_1Parser.MULTILINE_COMMENTS - 64)))) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





